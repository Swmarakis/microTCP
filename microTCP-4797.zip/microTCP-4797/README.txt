Giorgos Somarakis
csd4797

HY-335a Project Phase A


To run the MicroTCP-MASTER

mkdir build
cd build
cmake ..
make 

and you are ready to run the compiled files 'server.c' for the server side 
and the 'client.c' for the client side.

phase A is complete 

phase B is incomplete (can not send files)

